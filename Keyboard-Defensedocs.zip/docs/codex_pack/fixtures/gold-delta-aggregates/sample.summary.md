## Gold Delta Aggregates

### sample.analytics
Source: `C:\Users\Werem\OneDrive\Documents\Projects\Keyboard-Defense\docs\codex_pack\fixtures\gold-delta-aggregates\sample.analytics.json`

Net Δ: 0g • Largest gain: 40g • Largest loss: -50g

| Wave | Gain | Spend | Net | Events | Largest Δ |
| --- | --- | --- | --- | --- | --- |
| 1 | 60.0 | -30.0 | 30.0 | 3 | 40.0 |
| 2 | 30.0 | -50.0 | -20.0 | 2 | -50.0 |
| 3 | 40.0 | -50.0 | -10.0 | 2 | -50.0 |
