## Diagnostics Dashboard

### sample.analytics
Source: `C:\Users\Werem\OneDrive\Documents\Projects\Keyboard-Defense\docs\codex_pack\fixtures\diagnostics-dashboard\sample.analytics.json`

**Gold Delta**
| Δg | Gold | Time (s) |
| --- | --- | --- |
| -40 | 210 | 200.00 |
| +30 | 250 | 150.00 |
| -40 | 220 | 120.00 |
Net Δ: 30g • Largest loss: -40g • Events tracked: 5

**Passive Unlock Timeline**
| Passive | Details |
| --- | --- |
| armor | Armor L3 (140.25s,  Δ2.00) |
| regen | Regen L2 (80.50s,  Δ0.40) |
Total unlocks: 2
