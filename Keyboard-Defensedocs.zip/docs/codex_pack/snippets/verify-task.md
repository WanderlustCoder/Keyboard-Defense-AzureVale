## Verification

- Run `npm run lint`
- Run `npm run test`
- Run `npm run codex:validate-pack`
- Ensure acceptance criteria listed above pass (update screenshots, upload artifacts, etc.)
