# HUD Screenshot Gallery

Generated via `node scripts/docs/renderHudGallery.mjs --input <screenshots-dir>`.

| Shot | Screenshot | Badges | Snapshot Summary |
| --- | --- | --- | --- |
| hud-main (Fixture HUD capture showcasing compact tutorial banner) | [apps/keyboard-defense/artifacts/screenshots/hud-main.png](apps/keyboard-defense/artifacts/screenshots/hud-main.png) | `viewport:compact-height`<br />`tutorial:condensed`<br />`hud-passives:collapsed`<br />`hud-gold-events:collapsed`<br />`hud:prefers-condensed`<br />`diagnostics:condensed` | Compact viewport; Tutorial banner condensed; HUD passives collapsed; HUD gold events collapsed; Diagnostics condensed |
| options-overlay (Fixture options overlay with expanded passives) | [apps/keyboard-defense/artifacts/screenshots/options-overlay.png](apps/keyboard-defense/artifacts/screenshots/options-overlay.png) | `viewport:default-height`<br />`tutorial:default`<br />`hud-passives:expanded`<br />`hud-gold-events:expanded`<br />`options-passives:collapsed`<br />`diagnostics:expanded` | Default viewport; HUD passives expanded; HUD gold events expanded; Options passives collapsed; Diagnostics expanded |

## Metadata Sources

- `hud-main`: docs/codex_pack/fixtures/ui-snapshot/hud-main.meta.json
- `options-overlay`: docs/codex_pack/fixtures/ui-snapshot/options-overlay.meta.json

## Regeneration

```bash
node scripts/docs/renderHudGallery.mjs --input artifacts/screenshots --meta artifacts/screenshots
```

The command scans every `*.meta.json` file emitted by `scripts/hudScreenshots.mjs` and refreshes this document.