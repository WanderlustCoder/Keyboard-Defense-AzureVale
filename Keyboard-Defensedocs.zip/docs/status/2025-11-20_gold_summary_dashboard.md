## Gold Summary Dashboard - 2025-11-20

**Summary**
- Implemented `scripts/ci/goldSummaryReport.mjs`, a Codex-friendly parser that reads `gold-summary.ci.json` artifacts, aggregates per-file metrics (net delta, median/p90 gain & spend), and enforces configurable thresholds (`GOLD_SUMMARY_MIN_NET_DELTA`, `GOLD_SUMMARY_MAX_P90_SPEND_MAG`). The script emits Markdown + JSON summaries (`artifacts/summaries/gold-summary-report*.json`) so CI dashboards expose the latest economy stats without downloading artifacts.
- Tutorial smoke and e2e workflows now run the report immediately after the gold timeline dashboard, appending the Markdown table (file, net delta, median/p90 gain/spend, event count) to `$GITHUB_STEP_SUMMARY` and uploading the JSON alongside other summaries.
- Codex docs (Guide, Playbooks, dashboard appendix) document how to dry-run the report locally with fixtures: `node scripts/ci/goldSummaryReport.mjs docs/codex_pack/fixtures/gold-summary.json --summary temp/gold-summary-report.fixture.json --mode warn`.

**Next Steps**
1. Feed the gold summary report JSON into the broader analytics dashboard page so Codex has a single link per run (passive, timeline, summary, percentile guard).
2. Consider exporting baseline comparison data so the report can flag deviations against historical medians (not just absolute thresholds).

## Follow-up
- `docs/codex_pack/tasks/27-gold-summary-dashboard-integration.md`
- `docs/codex_pack/tasks/38-gold-analytics-board.md`
