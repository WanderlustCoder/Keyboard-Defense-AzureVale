## UI Snapshot Gallery & Metadata - 2025-11-20

**Summary**
- `scripts/hudScreenshots.mjs` now emits per-shot metadata (`*.meta.json`) capturing the `uiSnapshot`, a condensed badge list, and a human-readable summary for every PNG (`hud-main`, `options-overlay`, `tutorial-summary`, `wave-scorecard`). CI summaries now list those badges alongside each screenshot, and the sidecars land next to the PNGs for downstream tooling.
- Added `scripts/docs/renderHudGallery.mjs`, a lightweight doc generator that walks the metadata files and rebuilds `docs/hud_gallery.md` with badge tables, snapshot descriptions, and links to the captured PNGs. Fixtures under `docs/codex_pack/fixtures/ui-snapshot/` allow local dry-runs without rerunning Playwright.
- `docs/CODEX_GUIDE.md`, `docs/CODEX_PLAYBOOKS.md`, and `docs/codex_dashboard.md` now call out the gallery workflow so Codex contributors always regenerate the badges/doc whenever HUD screenshots change.

**Next Steps**
1. Wire the HUD gallery link into the Codex Portal once the responsive docs section is reorganized.
2. Consider embedding thumbnail previews (once stable assets exist) to make condensed-state regressions even faster to review.

## Follow-up
- `docs/codex_pack/tasks/33-tutorial-ui-snapshot-publishing.md`
