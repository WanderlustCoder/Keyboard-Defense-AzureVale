## Gold Percentile Alerts - 2025-11-20

**Summary**
- Introduced percentile baselines (`docs/codex_pack/fixtures/gold/gold-percentiles.baseline.json`) plus repo-configured thresholds (`apps/keyboard-defense/scripts/ci/gold-percentile-thresholds.json`) so gold summary medians/p90s now have an explicit reference curve.
- `scripts/ci/goldSummaryReport.mjs` accepts `--baseline`/`--thresholds` flags (env defaults wired for CI), compares each artifact’s median/p90 gain & spend against the baseline, and flags drift when absolute or percentage deltas exceed the configured bands. Fail/warn behavior is controlled by `GOLD_SUMMARY_REPORT_MODE`.
- CI smoke/e2e workflows run the percentiles check alongside the gold summary dashboard; the Markdown section now shows pass/fail rows per metric with diffs, and the uploaded JSON includes `percentileAlerts` for dashboards/automation.
- Codex docs/playbooks list the new command plus baseline/threshold file locations so contributors can refresh references whenever the economy tuning changes.

**Next Steps**
1. Automate baseline refreshes by wiring `npm run analytics:gold:summary` outputs into a helper script so Codex can regenerate the baseline file with a single command when economy tuning lands.
2. Feed the percentile alert JSON into a dedicated Codex dashboard tile once the static dashboard task (#7) is in flight, so nightly reviews show all gold metrics side-by-side.

## Follow-up
- `docs/codex_pack/tasks/30-gold-percentile-dashboard-alerts.md`
- `docs/codex_pack/tasks/39-gold-percentile-baseline-refresh.md`
- `docs/codex_pack/tasks/38-gold-analytics-board.md`
