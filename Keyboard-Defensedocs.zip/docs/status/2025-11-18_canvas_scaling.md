## Canvas Resolution Scaling - 2025-11-18

**Summary**
- Canvas now measures its flex container and device pixel ratio, then sets an internal render size so ultra-small layouts draw fewer pixels without losing clarity. The ResizeObserver path updates the renderer whenever the HUD stack wraps or the player rotates their device.
- DPR-specific media queries now reapply the scaling math when the browser zooms or accessibility zoom toggles, so Retina/HiDPI displays stay sharp without manual refreshes.
- CanvasRenderer exposes a `resize` method that recalculates cached dimensions and clears pattern caches, ensuring post-resize renders stay crisp.
- Added shared `calculateCanvasResolution` helper plus unit tests, so future overlays/devtools can reuse the same scaling math.
- Diagnostics/Tutorial responsive work already benefits: small tablets drop the workload from 960px wide to whatever width is actually visible while keeping the CSS aspect ratio consistent.
- A `ResolutionTransitionController` now captures the previous frame to an overlay canvas and fades it out over ~250 ms, masking DPR/viewport jumps without freezing gameplay or relying solely on CSS opacity.
- Every resolution change now emits a telemetry payload (`ui.canvasResolutionChanged`) and is captured inside analytics snapshots (`ui.resolution`, `ui.resolutionChanges[]`), so dashboards can confirm DPR listeners fired and HUD layout state during transitions.

**Next Steps**
1. Add a debug CLI (`npm run debug:dpr-transition`) plus Vitest coverage that simulates successive DPR buckets and asserts telemetry batches are emitted.
2. Capture DOM-level tests (Playwright or Vitest + JSDOM) that verify the new `data-canvas-transition` hooks pause HUD/diagnostics interactions and that reduced-motion short-circuits the overlay path.
