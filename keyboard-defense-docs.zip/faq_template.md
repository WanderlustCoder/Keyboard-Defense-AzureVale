# FAQ

## What kind of game is this?
A strategy roguelite controlled primarily by typing.

## Do I need to be a fast typist?
No. The game includes adjustable time pressure and practice options.

## Does it support different keyboard layouts?
Planned: QWERTY/AZERTY/Dvorak support and configurable wordpacks.

## Is there controller support?
Optional and not required; typing-first remains the primary interface.

## Is telemetry collected?
Off by default. If enabled, it collects limited anonymous aggregates.


