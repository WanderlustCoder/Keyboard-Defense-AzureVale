# Fact Sheet

## Title
Keyboard Defense

## Developer
<Your name / studio>

## Genre
Typing-first Strategy Roguelite

## Platforms
Windows (itch.io/Steam) - others TBD (macOS/Linux)

## Release
TBD

## Price
TBD

## Description
One paragraph summary.

## Features
- Bullet list

## Contact
- Email:
- Website:
- Social:



