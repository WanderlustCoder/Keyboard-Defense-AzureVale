# Press Release Template

FOR IMMEDIATE RELEASE

## Headline
Keyboard Defense brings day/night strategy and typing skill-building together

## Subhead
Command your kingdom by typing; build by day, defend by night

## Body
<City, Date> - <Studio> today announced Keyboard Defense, a typing-first strategy roguelite where players issue commands to build, explore, and survive escalating night waves.

Key features:
- Typing-first controls and adaptive difficulty
- Day planning and resource management
- Exploration with POIs and risk/reward choices
- Night defense with escalating threats

Media:
- Trailer: <link>
- Screenshots: <link>

Contact:
- <email>



