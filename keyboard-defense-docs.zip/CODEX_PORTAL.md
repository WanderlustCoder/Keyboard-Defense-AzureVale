# Archived Documentation

This document is archived from a pre-Godot implementation.
The current project is the Godot game at `apps/keyboard-defense-godot`.

See:
- `docs/GODOT_PROJECT.md`
- `docs/keyboard-defense-plans/README.md`
