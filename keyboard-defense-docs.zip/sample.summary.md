## Gold Delta Aggregates

_No gold delta data found._