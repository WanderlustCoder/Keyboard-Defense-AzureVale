# Community Guidelines

## Purpose
Create a welcoming community focused on learning and fun.

## Be Respectful
- No harassment, hate speech, or targeted abuse.
- No doxxing or sharing personal info.

## Keep It Safe for Learning
- Avoid profanity-laden wordpacks in default channels.
- Do not post content intended to shame others for typing speed.

## No Cheating / Exploits
- Do not share exploits that compromise other players.
- If you find a security issue, report it privately.

## Content Sharing (If Allowed)
- Share builds, strategies, and wordpacks that follow the UGC policy.

## Enforcement
Moderators may remove content or restrict access for violations.
Appeals process: provide an email/contact route.


