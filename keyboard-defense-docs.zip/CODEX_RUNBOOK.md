# Archived Codex Pack File

This file is archived from a pre-Godot implementation.
See `docs/GODOT_PROJECT.md` and `docs/keyboard-defense-plans/README.md`.
