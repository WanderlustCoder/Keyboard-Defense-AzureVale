# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog and adheres to Semantic Versioning.

## [Unreleased]
### Added
- 

### Changed
- 

### Fixed
- 

### Removed
- 

## [0.1.0] - YYYY-MM-DD
### Added
- Initial vertical slice.


